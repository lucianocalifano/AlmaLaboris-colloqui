<?php
	$connect = mysqli_connect("31.11.39.26", "Sql1507425", "6s44161433", "Sql1507425_4");
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename=clienti-colloqui.csv');
	$output = fopen("php://output", "w");
	fputcsv($output, array('ID', 'Nome', 'Cognome' , 'Email', 'Telefono', 'Data Inizio', 'Data Fine'));
	$query = "SELECT ea_users.id,first_name,last_name,email,phone_number,start_datetime,end_datetime FROM ea_users INNER JOIN ea_appointments WHERE ea_users.id = ea_appointments.id_users_customer order by start_datetime";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_assoc($result))
	{
		fputcsv($output, $row);
	}
		fclose($output);
?>