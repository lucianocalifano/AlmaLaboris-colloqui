<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 10:22:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2020-12-15 10:22:19 --> Unable to connect to the database
ERROR - 2020-12-15 10:28:00 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:30:53 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:40:22 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:40:31 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:42:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:44:40 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:51:33 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:51:39 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:53:00 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:56:55 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 10:57:00 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:03:51 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:04:34 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:06:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:10:33 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:12:12 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:12:22 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:12:25 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:13:18 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:14:08 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:14:32 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:14:46 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:15:55 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:22:56 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:47:39 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:49:48 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:55:50 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 11:56:57 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:01:32 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:02:39 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:02:47 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:03:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:03:16 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:03:34 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:04:06 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:06:12 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:06:20 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:08:37 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:10:22 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:11:38 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:03 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:05 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:07 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:15 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:27 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:12:58 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:15:32 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:16:34 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:18:47 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:19:06 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:19:27 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:19:35 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:20:07 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:20:43 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:21:10 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:21:12 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:21:17 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:21:52 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:22:17 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:22:54 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:23:55 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:27:33 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:33:53 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:38:24 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:44:49 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:44:51 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:44:52 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:45:53 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:45:55 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:00 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:01 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:04 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:04 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:05 --> Severity: error --> Exception: syntax error, unexpected '?>' /web/htdocs/www.almalaboris.com/home/colloqui/application/views/appointments/book.php 94
ERROR - 2020-12-15 12:46:34 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:47:46 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:53:59 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:57:10 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 12:57:13 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 13:14:59 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 13:18:26 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 15:08:30 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 17:00:34 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 17:02:02 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 17:10:17 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 17:11:20 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 17:26:02 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:52:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:56:38 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:58:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:58:06 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:59:00 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 19:59:04 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 20:21:48 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 20:22:45 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 20:23:26 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 21:09:30 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 22:50:28 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 22:50:38 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 22:51:15 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 22:51:43 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 22:52:03 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
ERROR - 2020-12-15 23:04:09 --> Severity: Warning --> mysqli_connect(): (HY000/2002): No such file or directory /web/htdocs/www.almalaboris.com/home/colloqui/filesLogic.php 3
