<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-08 12:22:23 --> Severity: Warning --> include(filesLogic.php): failed to open stream: No such file or directory C:\xampp\htdocs\easyapp\application\views\appointments\book.php 2
ERROR - 2020-12-08 12:22:23 --> Severity: Warning --> include(): Failed opening 'filesLogic.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\easyapp\application\views\appointments\book.php 2
ERROR - 2020-12-08 17:21:05 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 17:21:05 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 17:44:55 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 17:44:55 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 17:47:14 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 17:47:14 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:32:39 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:32:39 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:35:12 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:35:12 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:36:12 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:36:12 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:37:21 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:37:21 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:49:49 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:49:49 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 18:52:18 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 18:52:18 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 19:18:41 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 19:18:41 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 19:32:14 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 19:32:14 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 22:43:34 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 22:43:34 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 23:00:04 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 23:00:04 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 23:00:51 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 23:00:51 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 23:07:09 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 23:07:09 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 23:13:27 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 23:13:27 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-08 23:15:32 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-08 23:15:32 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
