<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-14 15:57:06 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
