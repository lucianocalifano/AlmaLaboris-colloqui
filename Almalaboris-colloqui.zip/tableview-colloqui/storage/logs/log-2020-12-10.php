<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 12:49:24 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 12:49:24 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 12:50:41 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 12:50:41 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 13:04:00 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 13:04:00 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 13:06:55 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 13:06:55 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 13:07:19 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 13:07:19 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 16:15:55 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 16:15:55 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 22:08:15 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 22:08:15 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 22:08:44 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 22:08:44 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 22:10:20 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 22:10:20 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 22:11:20 --> Email could not been sent. Mailer Error (Line 179): Could not instantiate mail function.
ERROR - 2020-12-10 22:11:20 --> #0 C:\xampp\htdocs\easyapp\application\controllers\Appointments.php(575): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email), Object(EA\Engine\Types\Text))
#1 C:\xampp\htdocs\easyapp\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyapp\index.php(353): require_once('C:\\xampp\\htdocs...')
#3 {main}
ERROR - 2020-12-10 22:36:59 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\easyapp\application\views\appointments\book_success.php 35
ERROR - 2020-12-10 22:37:26 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\easyapp\application\views\appointments\book_success.php 35
