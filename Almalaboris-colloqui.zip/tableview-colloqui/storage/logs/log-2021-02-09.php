<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-09 11:11:41 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
ERROR - 2021-02-09 19:39:27 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
