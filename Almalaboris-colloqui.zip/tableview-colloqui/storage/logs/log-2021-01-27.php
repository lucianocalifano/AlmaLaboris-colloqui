<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 11:40:42 --> Severity: error --> Exception: Too few arguments to function Appointments::book_success(), 0 passed in /web/htdocs/www.almalaboris.com/home/colloqui/system/core/CodeIgniter.php on line 532 and exactly 1 expected /web/htdocs/www.almalaboris.com/home/colloqui/application/controllers/Appointments.php 294
