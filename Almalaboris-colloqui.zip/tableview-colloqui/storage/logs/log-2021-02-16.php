<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-16 20:49:40 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
ERROR - 2021-02-16 20:49:43 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
ERROR - 2021-02-16 20:50:01 --> Severity: error --> Exception: $provider_id argument is not a valid numeric value:  /web/htdocs/www.almalaboris.com/home/colloqui/application/models/Providers_model.php 370
